//: Playground - noun: a place where people can play
//Ref: https://www.youtube.com/watch?v=Qh5NFikuNrI
import UIKit

//Conventional way to swap two items
func swapTwoInts(a:inout Int, b:inout Int)
{
    let temp = a
    a = b
    b = temp
}

var a = 1, b = 2
swapTwoInts(a: &a, b: &b)

a
b

// Generics Way swapping two values of any kind
// Create a place holder 'T', an replace all 'Int's with 'T'
func swapTwoValues<T>(a:inout T, b:inout T)
{
    let temp = a
    a = b
    b = temp
}

swapTwoValues(a: &a, b: &b)
a
b
var fName = "laxman"
var lName = "penmetsa"
swapTwoValues(a: &fName, b: &lName)
fName
lName

///Creating a generic stack
struct InStack <G>{
    var items = [G]()
    
    mutating func pushItem(item: G){
        items.append(item)
    }
    
    mutating func popItem() -> G{
        return items.removeLast()
    }
}


var myStack = InStack<String>()
myStack.items = ["George", "Andrea", "Micheal"]
myStack.popItem()
myStack.items
myStack.pushItem(item: "Laxman")
myStack.items


// Generic func to the index of array
func findIndex<L: Equatable>(arrayL: [L], itemToFind: L) -> Int? {
    
    for (index, item) in arrayL.enumerated(){
        if item == itemToFind {
            return index
        }
    }
    return nil
}

let result1 = findIndex(arrayL: [1,2,3,4,5], itemToFind: 4)
let result = findIndex(arrayL: myStack.items, itemToFind: "Laxman")

// Creating a readonly variable
var count: Int{
    return myStack.items.count
}






